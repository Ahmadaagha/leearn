<?php

require 'init.php' ;

if(isset($_POST['username'])&& isset($_POST['password'])&& isset($_POST['password_agin'])){
    $username =$_POST['username'];
    $password = $_POST['password'];
    $password_agen= $_POST['password_agin'];
    if(empty($username) || empty($password) || empty($password_agin)){
        echo "يجب عدم ترك اي حقل فارغ ";
    }if ($password !==$password_agin) {
        echo "كلمة السر غير صالحة";
    } else {

        mysqli_query($con, "insert into posts(username,password) value('$username','$password')");
        echo "نمت الاضافة بنجاح";
    }
    
}
?>

<form action="" nethod ="POST">
    username : <input type="text" name="username"><br>
    password : <input type="text" name="password"><br>
    password agin : <input type="text" name="password_agin"><br>
    <input type="submit" name="" value="send">

</form>